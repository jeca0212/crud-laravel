

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div>
            <h2 class="text-white">CRUD de Tareas</h2>
        </div>
        <div>
            <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">Crear tarea</a>
        </div>
    </div>

    <?php if(Session::get('success')): ?>
        <div class="alert alert-success mt-2">
            <strong><?php echo e(session::get('success')); ?></strong> <br>

        </div>
    <?php endif; ?>

    <div class="col-12 mt-4">
        <table class="table table-bordered text-white">
            <tr class="text-secondary">
                <th>Tarea</th>
                <th>Descripción</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th>Acción</th>
            </tr>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="fw-bold"><?php echo e($task->title); ?></td>
                <td><?php echo e($task->description); ?></td>
                <td>
                <?php echo e($task->due_date); ?>

                </td>
                <td>
                    <span class="badge bg-warning fs-6"><?php echo e($task->status); ?></span>
                </td>
                <td>
                    <a href="" class="btn btn-warning">Editar</a>

                    <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="post" class="d-inline borrar">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger borrar">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($tasks->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$('.borrar').submit(function(e){
    e.preventDefault();

    Swal.fire({
        title: "¿Estás seguro?",
  text: "La tarea se eliminará definitivamente",
  icon: "warning",
  showCancelButton: true,
  confirmButtonColor: "#3085d6",
  cancelButtonColor: "#d33",
  confirmButtonText: "Si, borrar",
  cancelButtonText: "Cancelar"
}).then((result) => {
  if (result.isConfirmed) {
    Swal.fire({
        title: "Borrada",
      text: "Tarea eliminada con éxito",
      icon: "success"
    });
  }
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-laravel\resources\views/index.blade.php ENDPATH**/ ?>